FITBUDDY - AI FITNESS PLAN GENERATOR

1. Open PowerShell in this folder.
2. Create a virtual environment:
   python -m venv .venv
3. Install dependencies:
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
4. Copy .env.example to .env and put your Gemini API key in .env:
   GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE
5. Start the application:
   .\.venv\Scripts\python.exe -m uvicorn app:app
6. Open in your browser:
   http://127.0.0.1:8000

Do not share your Gemini API key or commit .env to source control.
